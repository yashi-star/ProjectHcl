package com.example.customer_service.dto;

public record CustomerDto(
  Long id,
  String firstName,
  String lastName,
  String email,
  String phone
) {}
