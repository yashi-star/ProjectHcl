package com.example.customer_service.mapper;


import org.springframework.stereotype.Component;

import com.example.customer_service.dto.CustomerDto;
import com.example.customer_service.model.Customer;

@Component
public class CustomerMapper {

  public CustomerDto toDto(Customer customer) {
    if (customer == null) {
      return null;
    }
    return new CustomerDto(
      customer.getId(),
      customer.getFirstName(),
      customer.getLastName(),
      customer.getEmail(),
      customer.getPhone()
    );
  }

  public Customer toEntity(CustomerDto dto) {
    if (dto == null) {
      return null;
    }
    Customer customer = new Customer();
    customer.setId(dto.id());
    customer.setFirstName(dto.firstName());
    customer.setLastName(dto.lastName());
    customer.setEmail(dto.email());
    customer.setPhone(dto.phone());
    return customer;
  }
}
