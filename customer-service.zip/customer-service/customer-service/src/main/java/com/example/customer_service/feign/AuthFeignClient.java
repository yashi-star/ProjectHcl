package com.example.customer_service.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.customer_service.dto.UserDto;

@FeignClient(name = "auth-service")
public interface AuthFeignClient {

    @GetMapping("/auth/userinfo/{username}")
    UserDto getUserInfo(@PathVariable("username") String username);
}
