package com.example.customer_service.controller;


import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.example.customer_service.dto.CustomerDto;
import com.example.customer_service.dto.ProductDto;
import com.example.customer_service.service.CustomerService;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

  private final CustomerService customerService;

  @Autowired
  public CustomerController(CustomerService customerService) {
    this.customerService = customerService;
  }

  @GetMapping
  public List<CustomerDto> getAllCustomers() {
    return customerService.getAllCustomers();
  }

  @GetMapping("/{id}")
  public ResponseEntity<CustomerDto> getCustomerById(@PathVariable Long id) {
    CustomerDto customerDto = customerService.getCustomerById(id);
    if (customerDto == null) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok(customerDto);
  }

  @PostMapping
  public ResponseEntity<CustomerDto> createCustomer(@Valid @RequestBody CustomerDto customerDto) {
    CustomerDto createdCustomer = customerService.createCustomer(customerDto);
    return ResponseEntity.ok(createdCustomer);
  }

  @PutMapping("/{id}")
  public ResponseEntity<CustomerDto> updateCustomer(@PathVariable Long id, @Valid @RequestBody CustomerDto customerDto) {
    CustomerDto updatedCustomer = customerService.updateCustomer(id, customerDto);
    if (updatedCustomer == null) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok(updatedCustomer);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
    if (!customerService.deleteCustomer(id)) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok().build();
  }
  
  @GetMapping("/{id}/products/{productId}")
  public ResponseEntity<ProductDto> getProductForCustomer(@PathVariable Long productId) {
    ProductDto product = customerService.getProductDetails(productId); 
    if (product == null) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok(product);
  }
  
}
