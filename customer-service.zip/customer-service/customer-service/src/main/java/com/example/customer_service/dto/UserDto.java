package com.example.customer_service.dto;

public record UserDto(Long id, String username, String role) {}
