package com.example.customer_service.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer_service.dto.CustomerDto;
import com.example.customer_service.dto.ProductDto;
import com.example.customer_service.dto.UserDto;
import com.example.customer_service.feign.AuthFeignClient;
import com.example.customer_service.feign.ProductFeignClient;
import com.example.customer_service.mapper.CustomerMapper;
import com.example.customer_service.model.Customer;
import com.example.customer_service.repository.CustomerRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

  private final CustomerRepository customerRepository;
  private final CustomerMapper customerMapper;
  private final AuthFeignClient authFeignClient;
  private final ProductFeignClient productFeignClient;
  @Autowired
  public CustomerService(CustomerRepository customerRepository, CustomerMapper customerMapper,AuthFeignClient authFeignClient,ProductFeignClient productFeignClient) {
    this.customerRepository = customerRepository;
    this.customerMapper = customerMapper;
    this.authFeignClient = authFeignClient;
    this.productFeignClient = productFeignClient;
  }

  public List<CustomerDto> getAllCustomers() {
    return customerRepository.findAll()
        .stream()
        .map(customerMapper::toDto)
        .collect(Collectors.toList());
  }

  public CustomerDto getCustomerById(Long id) {
    return customerRepository.findById(id)
        .map(customerMapper::toDto)
        .orElse(null);
  }

  public CustomerDto createCustomer(CustomerDto customerDto) {
    Customer customer = customerMapper.toEntity(customerDto);
    Customer saved = customerRepository.save(customer);
    return customerMapper.toDto(saved);
  }

  public CustomerDto updateCustomer(Long id, CustomerDto customerDto) {
    return customerRepository.findById(id)
        .map(existing -> {
          existing.setFirstName(customerDto.firstName());
          existing.setLastName(customerDto.lastName());
          existing.setEmail(customerDto.email());
          existing.setPhone(customerDto.phone());
          customerRepository.save(existing);
          return customerMapper.toDto(existing);
        })
        .orElse(null);
  }

  public boolean deleteCustomer(Long id) {
    if (customerRepository.existsById(id)) {
      customerRepository.deleteById(id);
      return true;
    }
    return false;
  }
  
  
  public UserDto getUserInfoByUsername(String username) {
	    return authFeignClient.getUserInfo(username);
	  }

  public ProductDto getProductDetails(Long productId) {
	    return productFeignClient.getProductById(productId);
	  }
}
