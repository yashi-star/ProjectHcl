package com.example.product_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "products")
public class Product {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotNull
  private String name;

  private String description;

  @NotNull
  private Double price;

  private String brand;

  private String type;

  private String frameMaterial;

  private String lensMaterial;

  public Product() {
  }

  public Product(Long id, String name, String description, Double price, String brand, String type, String frameMaterial, String lensMaterial) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.price = price;
    this.brand = brand;
    this.type = type;
    this.frameMaterial = frameMaterial;
    this.lensMaterial = lensMaterial;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Double getPrice() {
    return price;
  }

  public void setPrice(Double price) {
    this.price = price;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getFrameMaterial() {
    return frameMaterial;
  }

  public void setFrameMaterial(String frameMaterial) {
    this.frameMaterial = frameMaterial;
  }

  public String getLensMaterial() {
    return lensMaterial;
  }

  public void setLensMaterial(String lensMaterial) {
    this.lensMaterial = lensMaterial;
  }
}
