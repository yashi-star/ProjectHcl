package com.example.product_service.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product_service.dto.ProductDto;
import com.example.product_service.mapper.ProductMapper;
import com.example.product_service.model.Product;
import com.example.product_service.repository.ProductRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

  private final ProductRepository productRepository;
  private final ProductMapper productMapper;

  @Autowired
  public ProductService(ProductRepository productRepository, ProductMapper productMapper) {
    this.productRepository = productRepository;
    this.productMapper = productMapper;
  }

  public List<ProductDto> getAllProducts() {
    return productRepository.findAll().stream()
        .map(productMapper::toDto)
        .collect(Collectors.toList());
  }

  public ProductDto getProductById(Long id) {
    return productRepository.findById(id)
        .map(productMapper::toDto)
        .orElse(null);
  }

  public ProductDto createProduct(ProductDto productDto) {
    Product product = productMapper.toEntity(productDto);
    Product saved = productRepository.save(product);
    return productMapper.toDto(saved);
  }

  public ProductDto updateProduct(Long id, ProductDto productDto) {
    return productRepository.findById(id)
        .map(existing -> {
          existing.setName(productDto.name());
          existing.setDescription(productDto.description());
          existing.setPrice(productDto.price());
          existing.setBrand(productDto.brand());
          existing.setType(productDto.type());
          existing.setFrameMaterial(productDto.frameMaterial());
          existing.setLensMaterial(productDto.lensMaterial());
          productRepository.save(existing);
          return productMapper.toDto(existing);
        }).orElse(null);
  }

  public boolean deleteProduct(Long id) {
    if (productRepository.existsById(id)) {
      productRepository.deleteById(id);
      return true;
    }
    return false;
  }
}
