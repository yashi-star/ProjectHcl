package com.example.product_service.mapper;


import org.springframework.stereotype.Component;

import com.example.product_service.dto.ProductDto;
import com.example.product_service.model.Product;

@Component
public class ProductMapper {

  public ProductDto toDto(Product product) {
    if (product == null) {
      return null;
    }
    return new ProductDto(
      product.getId(),
      product.getName(),
      product.getDescription(),
      product.getPrice(),
      product.getBrand(),
      product.getType(),
      product.getFrameMaterial(),
      product.getLensMaterial()
    );
  }

  public Product toEntity(ProductDto dto) {
    if (dto == null) {
      return null;
    }
    Product product = new Product();
    product.setId(dto.id());
    product.setName(dto.name());
    product.setDescription(dto.description());
    product.setPrice(dto.price());
    product.setBrand(dto.brand());
    product.setType(dto.type());
    product.setFrameMaterial(dto.frameMaterial());
    product.setLensMaterial(dto.lensMaterial());
    return product;
  }
}
