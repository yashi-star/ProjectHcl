package com.example.order_service.dto;

public record PaymentDetailsDto(
  Long id,
  String paymentMethod,
  Double amount
) {}
