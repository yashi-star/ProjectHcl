package com.example.order_service.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order_service.dto.CustomerDto;
import com.example.order_service.dto.OrderDto;
import com.example.order_service.dto.ProductDto;
import com.example.order_service.feign.CustomerFeignClient;
import com.example.order_service.feign.ProductFeignClient;
import com.example.order_service.mapper.OrderMapper;
import com.example.order_service.model.Order;
import com.example.order_service.repository.OrderRepository;

import jakarta.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

  private final OrderRepository orderRepository;
  private final OrderMapper orderMapper;
  private final CustomerFeignClient customerFeignClient;
  private final ProductFeignClient productFeignClient;
  
  @Autowired
  public OrderService(OrderRepository orderRepository, OrderMapper orderMapper,CustomerFeignClient customerFeignClient, ProductFeignClient productFeignClient) {
    this.orderRepository = orderRepository;
    this.orderMapper = orderMapper;
    this.customerFeignClient = customerFeignClient;
    this.productFeignClient = productFeignClient;
  }

  public List<OrderDto> getAllOrders() {
    return orderRepository.findAll()
        .stream()
        .map(orderMapper::toDto)
        .collect(Collectors.toList());
  }

  public OrderDto getOrderById(Long id) {
    return orderRepository.findById(id)
        .map(orderMapper::toDto)
        .orElse(null);
  }

  @Transactional
  public OrderDto createOrder(OrderDto orderDto) {
    Order order = orderMapper.toEntity(orderDto);
    Order savedOrder = orderRepository.save(order);
    return orderMapper.toDto(savedOrder);
  }

  @Transactional
  public OrderDto updateOrder(Long id, OrderDto orderDto) {
    return orderRepository.findById(id)
        .map(existingOrder -> {
          existingOrder.setCustomerId(orderDto.customerId());
          existingOrder.setOrderDate(orderDto.orderDate());

          // Handle items
          existingOrder.getItems().clear();
          if (orderDto.items() != null) {
            orderDto.items().forEach(itemDto -> {
              var item = orderMapper.toEntity(itemDto);
              item.setOrder(existingOrder);
              existingOrder.getItems().add(item);
            });
          }

          // Handle payment details
          if (orderDto.paymentDetails() != null) {
            var payment = orderMapper.toEntity(orderDto.paymentDetails());
            payment.setOrder(existingOrder);
            existingOrder.setPaymentDetails(payment);
          }

          Order updated = orderRepository.save(existingOrder);
          return orderMapper.toDto(updated);
        })
        .orElse(null);
  }

  public boolean deleteOrder(Long id) {
    if (orderRepository.existsById(id)) {
      orderRepository.deleteById(id);
      return true;
    }
    return false;
  }
  
  
  public void validateOrder(OrderDto orderDto) {

	    // Validate customer exists
	    CustomerDto customer = customerFeignClient.getCustomerById(orderDto.customerId());
	    if (customer == null) {
	      throw new IllegalArgumentException("Invalid customer ID");
	    }
  
  		//Validate products exist
  		orderDto.items().forEach(item -> {
  		ProductDto product = productFeignClient.getProductById(item.productId());
  		if (product == null) {
  			throw new IllegalArgumentException("Product not found: " + item.productId());
    }
  });
  }
}
