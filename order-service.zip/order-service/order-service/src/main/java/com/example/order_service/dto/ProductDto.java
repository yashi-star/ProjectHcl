package com.example.order_service.dto;

public record ProductDto(
		  Long id,
		  String name,
		  String description,
		  Double price,
		  String brand,
		  String type,
		  String frameMaterial,
		  String lensMaterial
		) {}
