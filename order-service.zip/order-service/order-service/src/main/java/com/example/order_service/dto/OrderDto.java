package com.example.order_service.dto;

import java.time.LocalDateTime;
import java.util.List;

public record OrderDto(
  Long id,
  Long customerId,
  LocalDateTime orderDate,
  List<OrderItemDto> items,
  PaymentDetailsDto paymentDetails
) {}
