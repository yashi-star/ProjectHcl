package com.example.order_service.controller;


import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.example.order_service.dto.OrderDto;
import com.example.order_service.service.OrderService;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

  private final OrderService orderService;

  @Autowired
  public OrderController(OrderService orderService) {
    this.orderService = orderService;
  }

  @GetMapping
  public List<OrderDto> getAllOrders() {
    return orderService.getAllOrders();
  }

  @GetMapping("/{id}")
  public ResponseEntity<OrderDto> getOrderById(@PathVariable Long id) {
    OrderDto orderDto = orderService.getOrderById(id);
    if (orderDto == null) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok(orderDto);
  }

  @PostMapping
  public ResponseEntity<OrderDto> createOrder(@Valid @RequestBody OrderDto orderDto) {
    OrderDto createdOrder = orderService.createOrder(orderDto);
    return ResponseEntity.ok(createdOrder);
  }

  @PutMapping("/{id}")
  public ResponseEntity<OrderDto> updateOrder(@PathVariable Long id, @Valid @RequestBody OrderDto orderDto) {
    OrderDto updatedOrder = orderService.updateOrder(id, orderDto);
    if (updatedOrder == null) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok(updatedOrder);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
    if (!orderService.deleteOrder(id)) {
      return ResponseEntity.notFound().build();
    }
    return ResponseEntity.ok().build();
  }
}
