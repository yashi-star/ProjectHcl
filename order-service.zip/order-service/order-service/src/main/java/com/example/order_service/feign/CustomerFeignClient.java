package com.example.order_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.order_service.dto.CustomerDto;

@FeignClient(name = "customer-service")
public interface CustomerFeignClient {

    @GetMapping("/customers/{customerId}")
    CustomerDto getCustomerById(@PathVariable("customerId") Long customerId);
}
