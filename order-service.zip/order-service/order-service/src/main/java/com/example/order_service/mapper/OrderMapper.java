package com.example.order_service.mapper;

import org.springframework.stereotype.Component;

import com.example.order_service.dto.OrderDto;
import com.example.order_service.dto.OrderItemDto;
import com.example.order_service.dto.PaymentDetailsDto;
import com.example.order_service.model.Order;
import com.example.order_service.model.OrderItem;
import com.example.order_service.model.PaymentDetails;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class OrderMapper {

  public OrderDto toDto(Order order) {
    if (order == null) {
      return null;
    }
    List<OrderItemDto> itemDtos = order.getItems() == null ? List.of() :
        order.getItems().stream().map(this::toDto).collect(Collectors.toList());

    PaymentDetailsDto paymentDto = toDto(order.getPaymentDetails());

    return new OrderDto(
        order.getId(),
        order.getCustomerId(),
        order.getOrderDate(),
        itemDtos,
        paymentDto
    );
  }

  public OrderItemDto toDto(OrderItem item) {
    if (item == null) {
      return null;
    }
    return new OrderItemDto(
        item.getId(),
        item.getProductId(),
        item.getQuantity()
    );
  }

  public PaymentDetailsDto toDto(PaymentDetails paymentDetails) {
    if (paymentDetails == null) {
      return null;
    }
    return new PaymentDetailsDto(
        paymentDetails.getId(),
        paymentDetails.getPaymentMethod(),
        paymentDetails.getAmount()
    );
  }

  public Order toEntity(OrderDto dto) {
    if (dto == null) {
      return null;
    }
    Order order = new Order();
    order.setId(dto.id());
    order.setCustomerId(dto.customerId());
    order.setOrderDate(dto.orderDate());
    if (dto.items() != null) {
      List<OrderItem> items = dto.items().stream()
          .map(this::toEntity)
          .toList();
      order.setItems(items);
      items.forEach(item -> item.setOrder(order));
    }
    if (dto.paymentDetails() != null) {
      PaymentDetails paymentDetails = toEntity(dto.paymentDetails());
      paymentDetails.setOrder(order);
      order.setPaymentDetails(paymentDetails);
    }
    return order;
  }

  public OrderItem toEntity(OrderItemDto dto) {
    if (dto == null) {
      return null;
    }
    OrderItem item = new OrderItem();
    item.setId(dto.id());
    item.setProductId(dto.productId());
    item.setQuantity(dto.quantity());
    return item;
  }

  public PaymentDetails toEntity(PaymentDetailsDto dto) {
    if (dto == null) {
      return null;
    }
    PaymentDetails paymentDetails = new PaymentDetails();
    paymentDetails.setId(dto.id());
    paymentDetails.setPaymentMethod(dto.paymentMethod());
    paymentDetails.setAmount(dto.amount());
    return paymentDetails;
  }
}
